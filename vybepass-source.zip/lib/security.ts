import {NextRequest} from 'next/server';import {createHmac,timingSafeEqual} from 'node:crypto';
const COOKIE='vybepass_admin';
function secret(){const s=process.env.ADMIN_SESSION_SECRET;if(!s||s.length<32)throw new Error('Configure ADMIN_SESSION_SECRET');return s}
export function signAdmin(){const until=Date.now()+8*60*60*1000;const value=String(until);return `${value}.${createHmac('sha256',secret()).update(value).digest('hex')}`}
export function adminCookie(){return COOKIE}
export function isAdmin(request:NextRequest){const token=request.cookies.get(COOKIE)?.value;if(!token)return false;const [expiry,mac]=token.split('.');if(!expiry||!mac||!/^\d+$/.test(expiry)||Date.now()>Number(expiry))return false;const expected=createHmac('sha256',secret()).update(expiry).digest('hex');if(mac.length!==expected.length)return false;return timingSafeEqual(Buffer.from(mac),Buffer.from(expected))}
export function sameOrigin(req:NextRequest){const configured=process.env.NEXT_PUBLIC_SITE_URL;if(!configured)return false;try{return req.headers.get('origin')===new URL(configured).origin}catch{return false}}
export function jsonHeaders(){return {'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}}
