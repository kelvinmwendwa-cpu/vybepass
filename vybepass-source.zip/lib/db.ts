import {createClient} from '@supabase/supabase-js';
export function db(){const url=process.env.NEXT_PUBLIC_SUPABASE_URL;const key=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!url||!key)throw new Error('Missing Supabase server configuration');return createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}})}
export type EventRow={id:string;slug:string;title:string;description:string;category:string;venue:string;city:string;starts_at:string;price:number;capacity:number;published:boolean;poster_url:string|null};
export const money=(v:number)=>'KSh '+Number(v).toLocaleString('en-KE');
