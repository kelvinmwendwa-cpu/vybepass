# VYBEPASS — Fresh Starter

A clean premium purple/black Next.js + Supabase event reservation website.

## Setup
1. Use a **new Supabase project**, not your old VYBEPASS database.
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. Copy `.env.example` to `.env.local` and fill in values. Never commit `.env.local`.
4. Run `npm install`, then `npm run dev`.
5. Visit http://localhost:3000 and http://localhost:3000/admin.
6. Set `NEXT_PUBLIC_SITE_URL` to your actual origin before deployment. Use HTTPS in production.

## Included
- Responsive premium event homepage, event catalog, event detail and booking form.
- Database-locked reservations preventing ordinary overselling; 15-minute expiry in availability calculation.
- Inactive individual ticket records, customer reference/email booking lookup, locked ticket UI.
- Admin password login, create/publish events, view recent bookings.

## IMPORTANT — NOT READY FOR PUBLIC LAUNCH
- Payment is intentionally absent; no QR codes are valid.
- Customer booking lookup is **NOT email-verified** and should not be exposed publicly. Add email OTP and durable rate limiting before launch.
- Admin login needs durable IP/account rate limiting, password hashing or managed authentication, and session revocation before launch.
- Add event editing, poster upload, cancellation, refund policy, privacy terms, event inventory stress tests, automated tests, accessibility audit, and deployment checks.
- The database stores personal information. Establish retention and access policies.
- Capacity edits after reservations must be guarded. Payment must use server-verified provider callbacks, not client confirmation.

This is a functional starter, not a security-audited finished product. Never expose service-role keys in client code.
