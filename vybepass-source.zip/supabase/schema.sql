-- Run in a NEW Supabase project. Do not apply to the old VYBEPASS database.
create extension if not exists pgcrypto;
create table if not exists public.events (
 id uuid primary key default gen_random_uuid(), slug text unique not null, title text not null, description text not null,
 category text not null, venue text not null, city text not null, starts_at timestamptz not null,
 price numeric(12,2) not null check(price>=0), capacity integer not null check(capacity>0),
 published boolean not null default false, poster_url text, created_at timestamptz not null default now());
create table if not exists public.bookings (
 id uuid primary key default gen_random_uuid(), reference text unique not null,
 event_id uuid not null references public.events(id), event_title text not null,
 customer_name text not null,customer_email text not null,customer_phone text not null,
 quantity integer not null check(quantity between 1 and 10),unit_price numeric(12,2) not null,
 total_amount numeric(12,2) not null,status text not null default 'pending' check(status in ('pending','expired','cancelled','paid')),
 expires_at timestamptz not null,created_at timestamptz not null default now());
create index if not exists bookings_event_status on public.bookings(event_id,status,expires_at);
create table if not exists public.tickets (
 id uuid primary key default gen_random_uuid(),booking_id uuid not null references public.bookings(id) on delete cascade,
 ticket_number integer not null,status text not null default 'inactive' check(status in ('inactive','active','used','cancelled')),
 secret_token uuid not null unique default gen_random_uuid(),checked_in_at timestamptz,
 unique(booking_id,ticket_number));
-- Lock down all data. The server uses the service role, never exposed to clients.
alter table public.events enable row level security;
alter table public.bookings enable row level security;
alter table public.tickets enable row level security;
revoke all on public.events,public.bookings,public.tickets from anon,authenticated;
create or replace function public.reserve_tickets(p_slug text,p_quantity integer,p_name text,p_email text,p_phone text)
returns text language plpgsql security definer set search_path='' as $$
declare e record;held integer;paid integer;ref text;bid uuid;
begin
 if p_quantity not between 1 and 10 or length(trim(p_name)) not between 2 and 150 or length(p_email)>254 or p_email !~* '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' or length(trim(p_phone)) not between 9 and 30 then raise exception 'INVALID_BOOKING';end if;
 select * into e from public.events where slug=p_slug and published=true for update;
 if not found then raise exception 'EVENT_UNAVAILABLE';end if;
 select coalesce(sum(quantity),0)::integer into held from public.bookings where event_id=e.id and status='pending' and expires_at>clock_timestamp();
 select coalesce(sum(quantity),0)::integer into paid from public.bookings where event_id=e.id and status='paid';
 if held+paid+p_quantity>e.capacity then raise exception 'SOLD_OUT';end if;
 ref:='VYB-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,12));
 insert into public.bookings(reference,event_id,event_title,customer_name,customer_email,customer_phone,quantity,unit_price,total_amount,expires_at)
 values(ref,e.id,e.title,trim(p_name),lower(trim(p_email)),trim(p_phone),p_quantity,e.price,e.price*p_quantity,clock_timestamp()+interval '15 minutes') returning id into bid;
 insert into public.tickets(booking_id,ticket_number) select bid,generate_series(1,p_quantity);
 return ref;
end;$$;
create or replace function public.lookup_booking(p_reference text,p_email text)
returns table(reference text,event_title text,quantity integer,total_amount numeric,status text,expires_at timestamptz)
language sql security definer set search_path='' as $$
 select b.reference,b.event_title,b.quantity,b.total_amount,b.status,b.expires_at
 from public.bookings b where b.reference=upper(trim(p_reference)) and b.customer_email=lower(trim(p_email)) limit 1;
$$;
revoke all on function public.reserve_tickets(text,integer,text,text,text) from public,anon,authenticated;
revoke all on function public.lookup_booking(text,text) from public,anon,authenticated;
grant execute on function public.reserve_tickets(text,integer,text,text,text) to service_role;
grant execute on function public.lookup_booking(text,text) to service_role;
-- No function for activating paid bookings or ticket QR codes is provided until payment integration.
