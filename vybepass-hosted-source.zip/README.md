# VYBEPASS

Kenyan event discovery, booking and owner administration. Hosted on Sites with D1 records, R2 event posters and platform sign-in.

## Access

The site remains owner-private. `/admin` and every administrative API operation require the authenticated email configured in the secret `ADMIN_EMAIL`. Customers see Discover events and My bookings, can access only their own booking records, and cannot create events or use admin actions. Changing the Site audience does not grant administrative access.

## Booking rules

- Paid-event reservations hold 1–10 tickets for 15 minutes. Expired and cancelled reservations release inventory. Prices and capacity are enforced on the server.
- Only free-event bookings currently become confirmed tickets. Payments and paid-ticket confirmation are intentionally not implemented.
- Confirmed bookings can be checked in once. A multi-ticket booking must arrive as one group. Owner-only undo check-in is recorded in activity history.
- Event capacity cannot be lowered below active reservations, including when a booking arrives during the save.
- Cancelled or expired bookings remain in administrator history. Expired pending reservations are hidden from customers.

## Email setup

Runtime secrets: `RESEND_API_KEY`, `RESEND_FROM_EMAIL` and `ADMIN_EMAIL`. Never put secret values in source or hosting configuration. The current resend.dev sender is for testing; a verified custom sender domain is required before emailing general customers. Admin Settings displays sender readiness. Provider acceptance does not prove delivery to the recipient inbox. An email failure does not discard a successful booking.

## Verification

Run from the checkout:

```
node tests/customer_journey.mjs
node tests/customer_views.mjs
node tests/admin_access.mjs
python3 tests/booking_integrity.py
node node_modules/typescript/bin/tsc --noEmit
```

The customer journey runs actual API handlers against isolated in-memory SQLite with simulated signed-in identities, an in-memory poster bucket and a mocked email provider. It does not create live bookings or send emails. View tests render React markup for customer and owner states. These are not browser or physical-device tests.

Before public launch, verify sender-domain delivery and complete a real phone test of poster layout, booking/cancellation and camera QR scanning. Camera scanning uses BarcodeDetector where supported; manual reference entry remains available. A customer needs a ChatGPT account for the platform sign-in currently used by this site.

Build and publish using the Sites workflow helpers. Preserve `.openai/hosting.json` identity and current audience. Add payments only after the remaining customer and security checks pass.
