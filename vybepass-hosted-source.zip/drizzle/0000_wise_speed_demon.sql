CREATE TABLE `bookings` (
	`id` text PRIMARY KEY NOT NULL,
	`event_id` text NOT NULL,
	`user_id` text NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`phone` text NOT NULL,
	`quantity` integer NOT NULL,
	`total` integer NOT NULL,
	`status` text NOT NULL,
	`created` text NOT NULL,
	`expires` text NOT NULL,
	`checked` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`event_id`) REFERENCES `events`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`category` text NOT NULL,
	`date` text NOT NULL,
	`venue` text NOT NULL,
	`city` text NOT NULL,
	`description` text NOT NULL,
	`price` integer NOT NULL,
	`capacity` integer NOT NULL,
	`published` integer DEFAULT 0 NOT NULL,
	`theme` text DEFAULT 'purple' NOT NULL
);
