import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {isOwnerAdmin} from '../../admin-access';
export async function POST(req:Request){
 const user=await getChatGPTUser();if(!isOwnerAdmin(user,env.ADMIN_EMAIL))return Response.json({error:'Administrator access required'},{status:403});
 if(req.headers.get('origin')&&new URL(req.headers.get('origin')!).origin!==new URL(req.url).origin)return Response.json({error:'Invalid origin'},{status:403});
 const type=req.headers.get('content-type')||'';if(!['image/jpeg','image/png','image/webp'].includes(type))return Response.json({error:'Use a JPG, PNG or WebP image.'},{status:400});
 if(Number(req.headers.get('content-length'))>5*1024*1024)return Response.json({error:'Maximum file size is 5 MB.'},{status:400});
 const bytes=await req.arrayBuffer();const b=new Uint8Array(bytes);if(bytes.byteLength>5*1024*1024||bytes.byteLength<12)return Response.json({error:'Invalid image size.'},{status:400});
 const valid=type==='image/png'?b[0]===137&&b[1]===80&&b[2]===78&&b[3]===71:type==='image/jpeg'?b[0]===255&&b[1]===216&&b[2]===255:new TextDecoder().decode(b.slice(0,4))==='RIFF'&&new TextDecoder().decode(b.slice(8,12))==='WEBP';if(!valid)return Response.json({error:'Invalid image file.'},{status:400});
 const key=crypto.randomUUID();await env.BUCKET!.put(key,bytes,{httpMetadata:{contentType:type}});return Response.json({url:'/api/posters?id='+key});
}
export async function GET(req:Request){const id=new URL(req.url).searchParams.get('id');if(!id||!/^[a-f0-9-]{36}$/.test(id))return new Response('Not found',{status:404});const file=await env.BUCKET!.get(id);if(!file)return new Response('Not found',{status:404});return new Response(file.body,{headers:{'Content-Type':file.httpMetadata?.contentType||'image/jpeg','Cache-Control':'public,max-age=86400','X-Content-Type-Options':'nosniff'}});}
