export function isVisibleBooking(booking:{status:string;expires:string},now:number):boolean {
 return booking.status!=='pending'||Date.parse(booking.expires)>now;
}
export function countHeldTickets(bookings:{event_id:string;status:string;expires:string;quantity:number}[],eventId:string,now:number):number {
 return bookings.reduce((total,b)=>total+(b.event_id===eventId&&(b.status==='confirmed'||(b.status==='pending'&&isVisibleBooking(b,now)))?b.quantity:0),0);
}
