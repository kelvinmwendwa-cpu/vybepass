import {env} from 'cloudflare:workers';
import {requireChatGPTUser} from '../chatgpt-auth';
import {isOwnerAdmin} from '../admin-access';
import Home from '../page';
export const dynamic='force-dynamic';
export default async function AdminPage(){
 const user=await requireChatGPTUser('/admin');
 if(!isOwnerAdmin(user,env.ADMIN_EMAIL))return <main className="workspace"><h1>Access restricted</h1><p>This admin panel is reserved for the VYBEPASS owner.</p><a href="/" className="dark">Return to events</a></main>;
 return <Home initialView="admin"/>;
}
