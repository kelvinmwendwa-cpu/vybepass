export function isOwnerAdmin(user:{email:string}|null,adminEmail:string|undefined):boolean {
 return !!user && !!adminEmail?.trim() && user.email.trim().toLowerCase()===adminEmail.trim().toLowerCase();
}
export const adminActions=new Set(['event','checkin','publish','deleteEvent','undoCheckin','cancelEvent','settings','blockCustomer','unblockCustomer']);
export const knownActions=new Set([...adminActions,'book','cancel']);
