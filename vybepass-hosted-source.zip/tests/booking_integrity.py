import sqlite3,re,pathlib,datetime
root=pathlib.Path(__file__).resolve().parent.parent
db=sqlite3.connect(':memory:')
for f in sorted((root/'drizzle').glob('*.sql')):db.executescript(f.read_text())
now='2026-10-17T13:00:00.000Z';expires='2026-10-17T13:15:00.000Z'
db.execute("INSERT INTO events (id,title,category,date,venue,city,description,price,capacity,published,theme) VALUES ('e','Test','Music','2026-12-01T15:00:00.000Z','Test venue','Nairobi','Test event',1500,2,1,'purple')")
source=(root/'app/api/platform/route.ts').read_text()
sql=re.search(r'INSERT INTO bookings .*?`',source).group(0)[:-1]
def book(ref,n=1,event='e',t=now):
 return db.execute(sql,(ref,'u','Test','test@example.com','0712345678',n,n,t,expires,event,t,t,n)).rowcount
assert book('a',2)==1
assert db.execute("SELECT total FROM bookings WHERE id='a'").fetchone()[0]==3000
assert book('b')==0,'Overselling must fail'
db.execute("UPDATE bookings SET status='cancelled' WHERE id='a'")
assert book('c')==1,'Cancellation must release capacity'
assert book('d',1,t='2026-10-17T13:16:00.000Z')==1,'Expired holds must release capacity'
assert book('unknown',event='missing')==0
assert book('past',t='2027-01-01T00:00:00.000Z')==0
check="UPDATE bookings SET checked=1 WHERE id=? AND status='confirmed' AND checked=0"
assert db.execute(check,('d',)).rowcount==0,'Unpaid check-in must fail'
db.execute("UPDATE bookings SET status='confirmed' WHERE id='d'")
assert db.execute(check,('d',)).rowcount==1
assert db.execute(check,('d',)).rowcount==0,'Repeat check-in must fail'
db.execute("UPDATE events SET price=0,capacity=50 WHERE id='e'")
assert book('free')==1
assert db.execute("SELECT status FROM bookings WHERE id='free'").fetchone()[0]=='confirmed'
db.execute("UPDATE events SET published=0 WHERE id='e'")
assert book('draft')==0,'Draft bookings must fail'
print('PASS: server-calculated prices; capacity; sold-out rejection; cancellation; expiry; missing/past/draft events; unpaid/repeated check-in; free tickets.')
