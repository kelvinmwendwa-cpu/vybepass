import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
function compile(path){return ts.transpileModule(fs.readFileSync(new URL(path,import.meta.url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText.replace(/^import .*;$/gm,'').replaceAll('export ','');}
const {isOwnerAdmin,adminActions,knownActions}=new Function(compile('../app/admin-access.ts')+';return {isOwnerAdmin,adminActions,knownActions}')();
const owner={email:'owner@example.com',userId:'owner'};
assert.equal(isOwnerAdmin(owner,undefined),false);
assert.equal(isOwnerAdmin(null,'owner@example.com'),false);
assert.equal(isOwnerAdmin({email:'OWNER@EXAMPLE.COM'},'owner@example.com'),true);
assert.equal(isOwnerAdmin({email:'owner@example.com.evil'},'owner@example.com'),false);
let current=null;const calls=[];
const env={
 ADMIN_EMAIL:'owner@example.com',
 DB:{prepare(sql){return {
  bind(...args){calls.push({sql,args});return this;},
  async run(){return {meta:{changes:1}};},
  async all(){
   if(sql.startsWith('SELECT e.'))return {results:[{id:'visible',published:1},{id:'hidden',published:0}]};
   return {results:[]};
  }
 };}}
};
const {isVisibleBooking}=new Function(compile('../app/booking-expiry.ts')+';return {isVisibleBooking}')();
const {GET,POST}=new Function('env','getChatGPTUser','isOwnerAdmin','adminActions','knownActions','isVisibleBooking',compile('../app/api/platform/route.ts')+';return {GET,POST}')(env,async()=>current,isOwnerAdmin,adminActions,knownActions,isVisibleBooking);
const request=(action,extra={},origin='https://tickets.example')=>new Request('https://tickets.example/api/platform',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify({action,...extra})});
for(const action of adminActions){current=null;assert.equal((await POST(request(action))).status,401);current={email:'other@example.com',userId:'customer'};assert.equal((await POST(request(action))).status,403,action);}
assert.equal(calls.length,0,'Unauthorized administrative requests must not query or mutate records');
current=owner;assert.equal((await POST(request('publish',{id:'event',published:true},'https://evil.example'))).status,403);assert.equal(calls.length,0);
assert.equal((await POST(request('grantAdmin'))).status,400);
assert.equal((await POST(request('publish',{id:'event',published:true}))).status,200);assert(calls.some(c=>c.sql.includes('UPDATE events')));assert(calls.some(c=>c.sql.includes('INSERT INTO audit_log')));
calls.length=0;current={email:'other@example.com',userId:'customer'};
assert.equal((await POST(request('cancel',{id:'booking'}))).status,200);assert(calls.some(c=>c.args.includes('customer')&&c.args.at(-1)===0),'Customer cancellation must enforce ownership');
current=null;const result=await (await GET()).json();assert.deepEqual(result.events,[{id:'visible',published:1}]);assert.deepEqual(result.bookings,[]);assert.deepEqual(result.audit,[]);assert.deepEqual(result.blocked,[]);assert.equal(result.isAdmin,false);
console.log('PASS: owner-only admin; fail-closed configuration; all admin actions reject anonymous and non-owner accounts; cross-origin denial; unknown action denial; audit logging; booking ownership; public data isolation.');

const expiry=Date.parse('2026-10-17T14:00:00.000Z');
const pending={status:'pending',expires:new Date(expiry).toISOString()};
assert.equal(isVisibleBooking(pending,expiry-1),true);
assert.equal(isVisibleBooking(pending,expiry),false);
assert.equal(isVisibleBooking(pending,expiry+1),false);
assert.equal(isVisibleBooking({status:'confirmed',expires:pending.expires},expiry+1),true);
assert.equal(isVisibleBooking({status:'cancelled',expires:pending.expires},expiry+1),true);
assert.equal(isVisibleBooking({status:'pending',expires:'invalid'},expiry),false);
console.log('PASS: pending reservation disappears exactly at expiry; confirmed tickets remain visible.');

const {countHeldTickets}=new Function(compile('../app/booking-expiry.ts')+';return {countHeldTickets}')();
const holds=[{event_id:'e',status:'pending',expires:new Date(expiry).toISOString(),quantity:2},{event_id:'e',status:'confirmed',expires:new Date(expiry).toISOString(),quantity:1},{event_id:'other',status:'confirmed',expires:new Date(expiry).toISOString(),quantity:5}];
assert.equal(countHeldTickets(holds,'e',expiry-1),3);
assert.equal(countHeldTickets(holds,'e',expiry),1);
assert.equal(100-countHeldTickets(holds,'e',expiry),99);
console.log('PASS: admin inventory releases expired quantity exactly at expiry and preserves confirmed stock.');
