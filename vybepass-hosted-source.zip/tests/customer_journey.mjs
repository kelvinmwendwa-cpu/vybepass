import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import {DatabaseSync} from 'node:sqlite';
import QRCode from 'qrcode';
function compile(path){return ts.transpileModule(fs.readFileSync(new URL(path,import.meta.url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText.replace(/^import .*;$/gm,'').replaceAll('export ','');}
const access=new Function(compile('../app/admin-access.ts')+';return {isOwnerAdmin,adminActions,knownActions}')();
const expiry=new Function(compile('../app/booking-expiry.ts')+';return {isVisibleBooking}')();
const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
for(const f of fs.readdirSync(new URL('../drizzle/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(new URL('../drizzle/'+f,import.meta.url),'utf8'));
let beforeRun=null;
class Statement{
 constructor(sql){this.sql=sql;this.args=[];}
 bind(...args){this.args=args;return this;}
 async all(){return {results:sqlite.prepare(this.sql).all(...this.args)};}
 async first(){return sqlite.prepare(this.sql).get(...this.args)??null;}
 async run(){if(beforeRun){const hook=beforeRun;beforeRun=null;await hook(this.sql);}const r=sqlite.prepare(this.sql).run(...this.args);return {meta:{changes:Number(r.changes)}};}
}
let current=null,clock=Date.parse('2026-10-17T14:30:00.000Z'),emailOk=true;
class TestDate extends Date{constructor(...args){super(...(args.length?args:[clock]));}static now(){return clock;}}
const mail=[];const objects=new Map();
const env={ADMIN_EMAIL:'owner@example.com',DB:{prepare:sql=>new Statement(sql),async batch(stmts){sqlite.exec('BEGIN');try{const result=[];for(const s of stmts)result.push(await s.run());sqlite.exec('COMMIT');return result;}catch(e){sqlite.exec('ROLLBACK');throw e;}}},BUCKET:{async put(k,b,o){objects.set(k,{bytes:b,httpMetadata:o.httpMetadata});},async get(k){const v=objects.get(k);return v?{...v,body:v.bytes}:null;}}};
const route=new Function('env','getChatGPTUser',...Object.keys(access),...Object.keys(expiry),'fetch','Date',compile('../app/api/platform/route.ts')+';return {GET,POST}')(env,async()=>current,...Object.values(access),...Object.values(expiry),async(url,opts)=>{mail.push({url,body:JSON.parse(opts.body)});return new Response(JSON.stringify(emailOk?{id:'email-test'}:{message:'Sender is unverified'}),{status:emailOk?200:403});},TestDate);
const poster=new Function('env','getChatGPTUser','isOwnerAdmin',compile('../app/api/posters/route.ts')+';return {GET,POST}')(env,async()=>current,access.isOwnerAdmin);
const owner={userId:'owner',email:'owner@example.com',displayName:'Owner'},alice={userId:'a',email:'alice@example.com',displayName:'Alice'},bob={userId:'b',email:'bob@example.com',displayName:'Bob'};
const event={id:'paid',title:'QA test event',category:'Music',date:'2026-12-01T19:00',venue:'Test venue',city:'Nairobi',description:'Isolated automated test',price:1500,capacity:3,published:1,theme:'purple'};
async function post(action,extra={},expected=200){const r=await route.POST(new Request('https://tickets.example/api/platform',{method:'POST',headers:{'Content-Type':'application/json',Origin:'https://tickets.example'},body:JSON.stringify({action,...extra})}));const body=await r.json();assert.equal(r.status,expected,JSON.stringify({action,body}));return body;}
async function get(){return (await route.GET()).json();}
const contact={name:'QA Customer',email:'alice@example.com',phone:'0712345678'};
const book=(eventId,quantity,expected=200,extra={})=>post('book',{eventId,quantity,...contact,...extra},expected);
current=owner;await post('event',{event});await post('event',{event:{...event,id:'free',title:'QA free event',price:0,capacity:20}});await post('event',{event:{...event,id:'draft',published:0}});
current=null;assert.deepEqual((await get()).events.map(e=>e.id).sort(),['free','paid']);assert.equal((await get()).bookings.length,0);await book('paid',1,401);
current=alice;await book('draft',1,400);await book('paid',0,400);await book('paid',11,400);await book('paid',1,400,{phone:'123'});
const a=await book('paid',2,200,{total:1,price:1});let row=sqlite.prepare('SELECT * FROM bookings WHERE id=?').get(a.id);assert.equal(row.total,3000);assert.equal(Date.parse(row.expires)-Date.parse(row.created),900000);assert.equal(row.status,'pending');
current=bob;assert.equal((await get()).bookings.length,0);await post('cancel',{id:a.id},400);await book('paid',2,400);
current=alice;await post('cancel',{id:a.id});assert.equal((await get()).events.find(e=>e.id==='paid').reserved,0);
const exp=await book('paid',2);clock+=900000;assert(!(await get()).bookings.some(b=>b.id===exp.id));assert.equal((await get()).events.find(e=>e.id==='paid').reserved,0);
current=bob;const replacement=await book('paid',3);assert.equal((await get()).events.find(e=>e.id==='paid').reserved,3);
current=owner;assert.match((await post('checkin',{id:exp.id},400)).error,/expired/);assert.match((await post('checkin',{id:replacement.id},400)).error,/unpaid/);await post('event',{event:{...event,capacity:2}},400);assert.equal(sqlite.prepare("SELECT capacity FROM events WHERE id='paid'").get().capacity,3);
current=alice;clock+=60001;const free=await book('free',2);row=sqlite.prepare('SELECT * FROM bookings WHERE id=?').get(free.id);assert.equal(row.status,'confirmed');assert.equal(row.total,0);const qr=await QRCode.toDataURL(free.id);assert(qr.startsWith('data:image/png;base64,'));
current=owner;await post('checkin',{id:free.id});await post('checkin',{id:free.id},400);await post('undoCheckin',{id:free.id});assert.equal(sqlite.prepare('SELECT checked FROM bookings WHERE id=?').get(free.id).checked,0);
await post('blockCustomer',{userId:bob.userId});current=bob;await book('free',1,403);current=owner;await post('unblockCustomer',{userId:bob.userId});await post('settings',{settings:{reservationsOpen:'false',notice:'Test announcement'}});current=bob;await book('free',1,400);current=owner;await post('settings',{settings:{reservationsOpen:'true'}});await post('settings',{settings:{supportEmail:'invalid'}},400);
await post('publish',{id:'paid',published:false});await post('deleteEvent',{id:'paid'},400);await post('deleteEvent',{id:'draft'});assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM events WHERE id='draft'").get().n,0);
await post('cancelEvent',{id:'free'});assert.equal(sqlite.prepare('SELECT status FROM bookings WHERE id=?').get(free.id).status,'cancelled');current=alice;await book('free',1,400);
current=owner;await post('event',{event:{...event,id:'rate',price:0,capacity:50}});current={userId:'rate-customer',email:'rate@example.com',displayName:'Rate'};for(let i=0;i<5;i++)await book('rate',1);await book('rate',1,429);
clock+=60001;env.RESEND_API_KEY='test-not-real';env.RESEND_FROM_EMAIL='VYBEPASS <onboarding@resend.dev>';const mailed=await book('rate',1);assert.equal(mailed.emailSent,true);assert.equal(mail.at(-1).body.to[0],contact.email);emailOk=false;const failedMail=await book('rate',1);assert.equal(failedMail.emailSent,false);assert(sqlite.prepare('SELECT id FROM bookings WHERE id=?').get(failedMail.id),'Booking must survive an email delivery failure');
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jL2kAAAAASUVORK5CYII=','base64');
const upload=()=>new Request('https://tickets.example/api/posters',{method:'POST',headers:{'Content-Type':'image/png',Origin:'https://tickets.example'},body:png});
current=alice;assert.equal((await poster.POST(upload())).status,403);current=owner;const uploaded=await (await poster.POST(upload())).json();assert(uploaded.url);const image=await poster.GET(new Request('https://tickets.example'+uploaded.url));assert.equal(image.status,200);assert.equal(image.headers.get('Content-Type'),'image/png');assert.equal(Buffer.compare(Buffer.from(await image.arrayBuffer()),png),0);
assert.equal((await poster.POST(new Request('https://tickets.example/api/posters',{method:'POST',headers:{'Content-Type':'image/png'},body:'not an image file'}))).status,400);
assert(sqlite.prepare('SELECT COUNT(*) n FROM audit_log').get().n>0);
// A booking arriving while the owner lowers capacity must not cause overselling.
current=owner;await post('event',{event:{...event,id:'race',capacity:3}});
current=alice;clock+=60001;await book('race',1);
current=owner;
beforeRun=async(sql)=>{assert(sql.startsWith('INSERT INTO events'));sqlite.prepare("INSERT INTO bookings(id,event_id,user_id,name,email,phone,quantity,total,status,created,expires,checked) VALUES('racing-booking','race','other','QA','qa@example.com','0712345678',1,1500,'pending',?,?,0)").run(new TestDate().toISOString(),new TestDate(clock+900000).toISOString());};
await post('event',{event:{...event,id:'race',capacity:1}},400);
assert.equal(sqlite.prepare("SELECT capacity FROM events WHERE id='race'").get().capacity,3);
console.log('PASS: full customer journey against isolated SQLite using actual request handlers: publication, customer isolation, server prices, capacity, cancellation, exact expiry/rebooking, free tickets/QR generation, check-in/replay/undo, blocking, booking pause, history-safe deletion, event cancellation, throttling, email success/failure handling, poster upload/download and permissions.');
